'use client';

import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Sky, Cloud, Html, Text, Environment, Stars } from '@react-three/drei';
import * as THREE from 'three';
import { createNoise2D } from 'simplex-noise';
import { achievementsData } from '@/lib/achievements/data';
import { Play, Pause, RotateCcw } from 'lucide-react';
import type { YearAchievements } from '@/lib/achievements-parser';

// --- KONFIGURACJA ---
const TERRAIN_SIZE = 1000;
const TERRAIN_SEGMENTS = 128;
const FLIGHT_SPEED = 0.3; // Jednostki na klatkę (przybliżenie)
const FLIGHT_HEIGHT = 30;
const PATH_RADIUS = 300;
const PATH_LOOPS = 2; // Ile razy pętla (lub długość trasy)

// Generowanie terenu
function Terrain() {
  const mesh = useRef<THREE.Mesh>(null);
  const noise2D = useMemo(() => createNoise2D(), []);

  const geometry = useMemo(() => {
    const geo = new THREE.PlaneGeometry(TERRAIN_SIZE, TERRAIN_SIZE, TERRAIN_SEGMENTS, TERRAIN_SEGMENTS);
    const pos = geo.attributes.position;
    
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const y = pos.getY(i);
      // Generowanie wysokości
      const noiseVal = 
        noise2D(x * 0.005, y * 0.005) * 20 + 
        noise2D(x * 0.02, y * 0.02) * 5 +
        noise2D(x * 0.1, y * 0.1) * 1;
        
      // Zapisujemy wysokość w Z (bo Plane jest domyślnie XY, ale obrócimy go później)
      pos.setZ(i, Math.max(-10, noiseVal));
    }
    
    geo.computeVertexNormals();
    return geo;
  }, [noise2D]);

  return (
    <mesh ref={mesh} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
      <primitive object={geometry} />
      <meshStandardMaterial 
        color="#3a7e3a" 
        roughness={0.8} 
        metalness={0.1}
        flatShading={false}
        side={THREE.DoubleSide}
      />
    </mesh>
  );
}

// Elementy otoczenia (Drzewa/Skały - uproszczone jako instanced mesh dla wydajności lub proste bryły)
function EnvironmentObjects() {
  return (
    <group>
       {/* Chmury */}
       <Cloud opacity={0.5} speed={0.4} width={50} depth={5} segments={20} position={[0, 80, -100]} />
       <Cloud opacity={0.5} speed={0.4} width={50} depth={5} segments={20} position={[100, 60, 100]} color="#e0e0e0" />
       <Cloud opacity={0.5} speed={0.4} width={50} depth={5} segments={20} position={[-100, 90, 50]} />
       <Stars radius={300} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
    </group>
  );
}

// Baner Wyników
function ResultBanner({ yearData, position }: { yearData: YearAchievements, position: THREE.Vector3 }) {
  const [hovered, setHovered] = useState(false);
  
  const allAchievements = yearData.achievements;
  const numResults = allAchievements.length;
  const columns = numResults <= 6 ? 1 : numResults <= 12 ? 2 : 3;

  return (
    <group position={position}>
      {/* Linia łącząca z ziemią */}
      <mesh position={[0, -FLIGHT_HEIGHT / 2, 0]}>
         <cylinderGeometry args={[0.2, 0.2, FLIGHT_HEIGHT, 8]} />
         <meshStandardMaterial color="white" transparent opacity={0.3} />
      </mesh>
      
      {/* Marker 3D (Kulka) */}
      <mesh position={[0, 0, 0]}>
        <sphereGeometry args={[2, 16, 16]} />
        <meshStandardMaterial color="#fbbf24" emissive="#f59e0b" emissiveIntensity={2} />
      </mesh>

      {/* HTML Overlay - widoczny zawsze */}
      <Html
        center
        distanceFactor={50}
        zIndexRange={[100, 0]}
        style={{
            pointerEvents: 'none', // Klikanie obsługiwane przez UI nadrzędne jeśli trzeba, tu tylko wyświetlanie
            transform: 'scale(1)',
        }}
      >
        <div className="relative group">
            <div className={`
                bg-black/80 backdrop-blur-md border border-yellow-500/50 p-4 rounded-xl text-white min-w-[300px]
                transition-all duration-500 transform
                ${hovered ? 'scale-110 opacity-100' : 'scale-100 opacity-90'}
            `}>
                <h3 className="text-3xl font-bold text-yellow-400 font-mono text-center mb-2">{yearData.year}</h3>
                
                <div 
                    className="grid gap-2 text-xs text-left"
                    style={{ gridTemplateColumns: `repeat(${columns}, 1fr)` }}
                >
                    {allAchievements.map((ach, i) => (
                        <div key={i} className="bg-white/5 p-2 rounded border border-white/10">
                            <div className="text-sky-300 font-semibold mb-1 truncate">{ach.title}</div>
                            <div className="text-gray-400 text-[10px]">{ach.category}</div>
                            {ach.coeff !== '-' && <div className="text-yellow-600 font-mono">{ach.coeff} coeff</div>}
                        </div>
                    ))}
                </div>
            </div>
        </div>
      </Html>
    </group>
  );
}

// Kontroler Lotu
function FlightController({ 
    isPlaying, 
    setIsPlaying,
    progress,
    setProgress
}: { 
    isPlaying: boolean, 
    setIsPlaying: (v: boolean) => void,
    progress: React.MutableRefObject<number>,
    setProgress: (v: number) => void
}) {
  const { camera } = useThree();
  
  // Tworzenie ścieżki
  const curve = useMemo(() => {
    const points = [];
    // Generuj spiralną ścieżkę nad terenem
    for (let i = 0; i <= 20; i++) {
      const t = i / 20;
      const angle = t * Math.PI * 4; // 2 obroty
      const r = PATH_RADIUS * (1 - t * 0.2); // Lekko zwężająca się
      const x = Math.cos(angle) * r;
      const z = Math.sin(angle) * r;
      // Y - wysokość, trochę falująca
      const y = FLIGHT_HEIGHT + Math.sin(t * 10) * 5; 
      points.push(new THREE.Vector3(x, y, z));
    }
    return new THREE.CatmullRomCurve3(points);
  }, []);

  useFrame((state, delta) => {
    if (isPlaying) {
      // Aktualizuj postęp
      const speed = FLIGHT_SPEED * 0.2 * delta; // Prędkość niezależna od klatek
      progress.current += speed;
      
      if (progress.current >= 1) {
        progress.current = 0; // Pętla
        // Można tu zatrzymać: setIsPlaying(false);
      }

      // Pobierz pozycję na krzywej
      const point = curve.getPointAt(progress.current);
      const lookAtPoint = curve.getPointAt(Math.min(progress.current + 0.02, 1));

      // Ustaw kamerę
      camera.position.copy(point);
      camera.lookAt(lookAtPoint);
      
      // Lekki przechył (roll) na zakrętach
      const tangent = curve.getTangentAt(progress.current);
      // Prosta symulacja przechyłu - im bardziej skręca, tym większy roll
      // Tutaj uproszczone: lekki stały przechył lub bazujący na krzywiźnie (zaawansowane)
      camera.up.set(0, 1, 0); // Reset up vector
    }
  });

  // Rozmieszczenie banerów wzdłuż trasy
  const banners = useMemo(() => {
      return achievementsData.map((yearData, index) => {
          // Rozłóż równomiernie na trasie
          const t = (index + 1) / (achievementsData.length + 1);
          const pos = curve.getPointAt(t);
          // Przesuń lekko w bok od trasy, żeby kamera nie przelatywała "przez" baner
          const tangent = curve.getTangentAt(t);
          const normal = new THREE.Vector3(0, 1, 0);
          const side = new THREE.Vector3().crossVectors(tangent, normal).normalize().multiplyScalar(15);
          
          const bannerPos = pos.clone().add(side);
          
          return <ResultBanner key={yearData.year} yearData={yearData} position={bannerPos} />;
      });
  }, [curve]);

  return (
    <group>
      {/* Wizualizacja trasy (opcjonalnie, np. jako "ślad") */}
      {banners}
    </group>
  );
}

export default function NatureFlightMap() {
    const [isPlaying, setIsPlaying] = useState(false);
    const progressRef = useRef(0);

    // Reset pozycji kamery na start
    const handleReset = () => {
        setIsPlaying(false);
        progressRef.current = 0;
    };

    return (
        <div className="relative w-full h-full bg-black">
            <Canvas shadows camera={{ position: [0, 50, 350], fov: 60 }}>
                <Sky sunPosition={[100, 20, 100]} turbidity={0.5} rayleigh={0.5} mieCoefficient={0.005} mieDirectionalG={0.8} />
                <ambientLight intensity={0.5} />
                <directionalLight 
                    position={[100, 100, 50]} 
                    intensity={1.5} 
                    castShadow 
                    shadow-mapSize={[1024, 1024]}
                />
                
                <Terrain />
                <EnvironmentObjects />
                
                <FlightController 
                    isPlaying={isPlaying} 
                    setIsPlaying={setIsPlaying}
                    progress={progressRef}
                    setProgress={(v) => progressRef.current = v}
                />
                
                <Environment preset="park" />
            </Canvas>

            {/* UI Controls */}
            <div className="absolute bottom-12 left-1/2 -translate-x-1/2 z-50 flex items-center gap-4 bg-black/60 backdrop-blur-md p-3 rounded-full border border-white/10">
                <button 
                    onClick={() => setIsPlaying(!isPlaying)}
                    className={`flex items-center gap-2 px-6 py-2 rounded-full font-bold transition-colors ${
                        isPlaying ? 'bg-white/10 text-white hover:bg-white/20' : 'bg-yellow-500 text-black hover:bg-yellow-400'
                    }`}
                >
                    {isPlaying ? <Pause size={18} /> : <Play size={18} />}
                    {isPlaying ? 'Pauza' : 'Start Lotu'}
                </button>
                
                <button 
                    onClick={handleReset}
                    className="p-2 text-gray-400 hover:text-white transition-colors"
                    title="Resetuj trasę"
                >
                    <RotateCcw size={20} />
                </button>
            </div>

            {/* Tytuł / Instrukcja */}
            <div className="absolute top-8 left-1/2 -translate-x-1/2 text-center pointer-events-none">
                <h1 className="text-2xl font-bold text-white drop-shadow-lg">Historia Lotów - Widok z Trasy</h1>
                <p className="text-sm text-gray-300 drop-shadow-md">Obserwuj wyniki na przestrzeni lat w naturalnym środowisku</p>
            </div>
        </div>
    );
}

