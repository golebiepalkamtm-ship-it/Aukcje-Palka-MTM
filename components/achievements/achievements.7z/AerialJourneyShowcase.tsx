'use client';

import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Sky, Cloud, Html, Stars, Environment, PerspectiveCamera } from '@react-three/drei';
import * as THREE from 'three';
import { createNoise2D } from 'simplex-noise';
import { achievementsData } from '@/lib/achievements/data';
import { Play, Pause, RotateCcw, Map as MapIcon, Trophy } from 'lucide-react';
import type { YearData } from '@/lib/achievements/types';

// --- KONFIGURACJA ---
const TERRAIN_SIZE = 1600;
const TERRAIN_SEGMENTS = 196;
const FLIGHT_SPEED = 0.15; // Wolniejszy, majestatyczny lot
const FLIGHT_HEIGHT = 45;
const PATH_RADIUS = 500;

// --- TEXTURE GENERATION HELPERS ---
// Generujemy teksturę proceduralną dla terenu, aby wyglądał bardziej jak Google Earth
function useTerrainTexture() {
  const [texture, setTexture] = useState<THREE.CanvasTexture | null>(null);

  useEffect(() => {
    if (typeof document === 'undefined') return;

    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const context = canvas.getContext('2d');
    if (!context) return;

    // Tło - ziemia
    context.fillStyle = '#3a4d2e'; 
    context.fillRect(0, 0, 512, 512);

    // Szum dla detali (uproszczony)
    for (let i = 0; i < 4000; i++) {
        const x = Math.random() * 512;
        const y = Math.random() * 512;
        const size = Math.random() * 4;
        context.fillStyle = Math.random() > 0.5 ? '#4a6b38' : '#2d3b22'; // Różne odcienie zieleni
        context.beginPath();
        context.arc(x, y, size, 0, Math.PI * 2);
        context.fill();
    }

    const tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(4, 4);
    setTexture(tex);
  }, []);

  return texture;
}

// --- KOMPONENTY ---

function Terrain() {
  const mesh = useRef<THREE.Mesh>(null);
  const noise2D = useMemo(() => createNoise2D(), []);
  const texture = useTerrainTexture();

  const geometry = useMemo(() => {
    const geo = new THREE.PlaneGeometry(TERRAIN_SIZE, TERRAIN_SIZE, TERRAIN_SEGMENTS, TERRAIN_SEGMENTS);
    const pos = geo.attributes.position;
    
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const y = pos.getY(i);
      
      // Wielowarstwowy szum dla realistycznych gór i dolin
      let noise = noise2D(x * 0.002, y * 0.002) * 40; // Baza
      noise += noise2D(x * 0.005, y * 0.005) * 20; // Detal średni
      noise += noise2D(x * 0.02, y * 0.02) * 5; // Detal drobny
      noise += noise2D(x * 0.1, y * 0.1) * 1; // Szorstkość
        
      // Podniesienie gór, spłaszczenie dolin
      const height = noise > 0 ? Math.pow(noise, 1.2) : noise;
      pos.setZ(i, Math.max(-20, height));
    }
    
    geo.computeVertexNormals();
    return geo;
  }, [noise2D]);

  return (
    <mesh ref={mesh} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
      <primitive object={geometry} />
      <meshStandardMaterial 
        map={texture || undefined}
        color={!texture ? "#4a6b38" : undefined}
        roughness={0.8} 
        metalness={0.1}
        side={THREE.DoubleSide}
      />
    </mesh>
  );
}

function Trees() {
    const count = 800; // Więcej drzew dla gęstości
    const meshRef = useRef<THREE.InstancedMesh>(null);
    const noise2D = useMemo(() => createNoise2D(), []);
    const tempObject = useMemo(() => new THREE.Object3D(), []);

    useEffect(() => {
        if (!meshRef.current) return;
        
        let idx = 0;
        for (let i = 0; i < count; i++) {
            const x = (Math.random() - 0.5) * TERRAIN_SIZE * 0.9;
            const z = (Math.random() - 0.5) * TERRAIN_SIZE * 0.9;
            
            // Odtworzenie wysokości terenu w tym punkcie (uproszczone)
            let noise = noise2D(x * 0.002, z * 0.002) * 40;
            noise += noise2D(x * 0.005, z * 0.005) * 20;
            const height = noise > 0 ? Math.pow(noise, 1.2) : noise;

            if (height < 0) continue; // Bez drzew w "wodzie"

            // Skala i rotacja dla różnorodności
            const scale = 2 + Math.random() * 3;
            tempObject.position.set(x, height, z);
            tempObject.scale.set(scale, scale * (1 + Math.random()), scale);
            tempObject.rotation.y = Math.random() * Math.PI * 2;
            
            tempObject.updateMatrix();
            meshRef.current.setMatrixAt(idx++, tempObject.matrix);
        }
        meshRef.current.instanceMatrix.needsUpdate = true;
    }, [noise2D, tempObject]);

    return (
        <instancedMesh ref={meshRef} args={[undefined, undefined, count]} castShadow receiveShadow>
            <coneGeometry args={[1.5, 6, 6]} />
            <meshStandardMaterial color="#1a331a" roughness={0.9} />
        </instancedMesh>
    );
}

// Marker 3D w stylu Google Earth (szpilka + karta)
function ResultMarker({ yearData, position, isVisible }: { yearData: YearData, position: THREE.Vector3, isVisible: boolean }) {
  const allResults = useMemo(() => yearData.divisions.flatMap(d => d.results), [yearData]);
  const isMaster = yearData.totalMasterTitles > 0;
  
  return (
    <group position={position}>
      {/* Linia kotwicząca (tether) */}
      <mesh position={[0, -20, 0]}>
         <cylinderGeometry args={[0.1, 0.1, 40, 8]} />
         <meshBasicMaterial color="white" transparent opacity={0.3} />
      </mesh>
      
      {/* Pin/Punkt */}
      <mesh>
        <sphereGeometry args={[2, 16, 16]} />
        <meshStandardMaterial 
            color={isMaster ? "#fbbf24" : "#38bdf8"} 
            emissive={isMaster ? "#f59e0b" : "#0ea5e9"}
            emissiveIntensity={1.5}
        />
      </mesh>
      
      {/* Pulsujący pierścień */}
      <mesh rotation={[-Math.PI/2, 0, 0]} position={[0, 0, 0]}>
        <ringGeometry args={[2.5, 3, 32]} />
        <meshBasicMaterial color="white" transparent opacity={0.5} side={THREE.DoubleSide} />
      </mesh>

      {/* UI Card */}
      <Html
        center
        distanceFactor={50} // Skaluje się wraz z odległością jak w Google Earth
        zIndexRange={[100, 0]}
        style={{
            pointerEvents: 'none',
            opacity: isVisible ? 1 : 0.4,
            transition: 'opacity 0.5s ease-in-out',
            transform: `scale(${isVisible ? 1 : 0.8})`,
        }}
      >
        <div className="flex flex-col items-center">
            {/* Label roku nad kartą */}
            <div className="mb-2 px-3 py-1 bg-black/80 backdrop-blur rounded-full border border-white/20 text-white font-bold text-lg shadow-lg">
                {yearData.year}
            </div>

            {/* Karta szczegółów - widoczna gdy bliżej */}
            {isVisible && (
                <div className="bg-black/90 backdrop-blur-xl border-l-4 border-yellow-500 p-4 rounded-r-xl shadow-2xl w-[280px] text-left animate-in fade-in slide-in-from-bottom-4 duration-500">
                    <div className="flex items-center justify-between mb-2">
                         <div className="text-xs text-gray-400 uppercase tracking-wider font-semibold">Osiągnięcia</div>
                         {isMaster && <Trophy size={14} className="text-yellow-400" />}
                    </div>
                    <div className="space-y-2 max-h-[200px] overflow-hidden relative">
                        {allResults.slice(0, 4).map((res, i) => (
                            <div key={i} className="text-sm border-b border-white/10 pb-1 last:border-0">
                                <div className="text-white font-medium truncate">{res.title}</div>
                                <div className="text-gray-400 text-xs flex justify-between">
                                    <span>{res.category}</span>
                                    {res.coefficient && <span className="text-yellow-500/80">{res.coefficient} coef</span>}
                                </div>
                            </div>
                        ))}
                        {allResults.length > 4 && (
                            <div className="text-xs text-center text-gray-500 pt-1 italic">
                                + {allResults.length - 4} więcej...
                            </div>
                        )}
                        {/* Gradient maskujący dół */}
                        <div className="absolute bottom-0 left-0 w-full h-6 bg-gradient-to-t from-black/90 to-transparent pointer-events-none" />
                    </div>
                </div>
            )}
        </div>
      </Html>
    </group>
  );
}

function FlightController({ 
    isPlaying, 
    progress,
}: { 
    isPlaying: boolean, 
    progress: React.MutableRefObject<number>,
}) {
  const { camera } = useThree();
  const smoothTarget = useRef(new THREE.Vector3());
  const smoothLookAt = useRef(new THREE.Vector3());
  
  // Definicja ścieżki - rozległa, organiczna pętla nad terenem
  const curve = useMemo(() => {
    const points = [];
    const loops = 1;
    const segments = 20;
    for (let i = 0; i <= segments; i++) {
      const t = i / segments;
      const angle = t * Math.PI * 2 * loops;
      
      // Zmienna odległość od środka dla nie-kołowego kształtu
      const r = PATH_RADIUS + Math.cos(angle * 3) * 100; 
      
      const x = Math.sin(angle) * r;
      const z = Math.cos(angle) * r;
      // Wysokość zmienia się łagodnie
      const y = FLIGHT_HEIGHT + Math.sin(angle * 2) * 20;
      
      points.push(new THREE.Vector3(x, y, z));
    }
    return new THREE.CatmullRomCurve3(points, true, 'centripetal', 0.5);
  }, []);

  useFrame((state, delta) => {
    if (!isPlaying) return;

    // Update progress
    progress.current += (FLIGHT_SPEED * 0.1 * delta);
    if (progress.current > 1) progress.current = 0;

    // Get target positions
    const targetPos = curve.getPointAt(progress.current);
    const lookAtTarget = curve.getPointAt((progress.current + 0.03) % 1); // Look slightly ahead

    // Smooth camera movement (cinematic damping)
    smoothTarget.current.lerp(targetPos, 0.05); // Bardzo płynne podążanie
    smoothLookAt.current.lerp(lookAtTarget, 0.05);

    camera.position.copy(smoothTarget.current);
    camera.lookAt(smoothLookAt.current);
    
    // Subtelny przechył kamery (Banking)
    const tangent = curve.getTangentAt(progress.current);
    const curvature = tangent.x; // Proste przybliżenie skrętu
    camera.rotation.z = THREE.MathUtils.lerp(camera.rotation.z, -curvature * 0.2, 0.05);
  });

  // Render markers
  const markers = useMemo(() => {
      return achievementsData.map((yearData, index) => {
          // Rozmieść wzdłuż krzywej
          const t = index / achievementsData.length;
          const pointOnCurve = curve.getPointAt(t);
          
          // Przesunięcie w bok
          const tangent = curve.getTangentAt(t);
          const normal = new THREE.Vector3(0, 1, 0);
          const binormal = new THREE.Vector3().crossVectors(tangent, normal).normalize();
          
          const distance = 60; // Odległość od trasy
          const pos = pointOnCurve.clone().add(binormal.multiplyScalar(distance));
          pos.y += 10; // Wyżej niż trasa

          return { yearData, pos, t };
      });
  }, [curve]);

  return (
    <>
        {markers.map((m, i) => {
             // Pokaż szczegóły tylko gdy blisko (progress)
             // Odległość w "czasie" (t) na krzywej
             const dist = Math.abs(progress.current - m.t);
             const isVisible = dist < 0.08 || dist > 0.92; // Visible range (uwzględniając pętlę)
             
             return (
                <ResultMarker 
                    key={m.yearData.year} 
                    yearData={m.yearData} 
                    position={m.pos} 
                    isVisible={isVisible}
                />
             );
        })}
    </>
  );
}

// --- GŁÓWNY KOMPONENT ---

export default function AerialJourneyShowcase() {
    const [isPlaying, setIsPlaying] = useState(false);
    const progressRef = useRef(0);
    
    return (
        <div className="relative w-full h-screen bg-gray-900 overflow-hidden">
            <Canvas shadows dpr={[1, 1.5]} gl={{ antialias: true }}>
                <PerspectiveCamera makeDefault position={[0, 150, 600]} fov={45} />
                
                {/* Atmosfera Google Earth */}
                <Sky 
                    sunPosition={[10, 10, 100]} 
                    turbidity={0.1} 
                    rayleigh={0.5} 
                    mieCoefficient={0.005} 
                    mieDirectionalG={0.8} 
                    distance={4500}
                />
                {/* Używamy primitive object dla fog, aby uniknąć problemów z typowaniem JSX */}
                <primitive object={new THREE.Fog('#dbeafe', 200, 1200)} attach="fog" />
                
                <ambientLight intensity={0.6} />
                <directionalLight 
                    position={[100, 200, 50]} 
                    intensity={1.5} 
                    castShadow 
                    shadow-bias={-0.0005}
                    shadow-mapSize={[2048, 2048]}
                />

                <Terrain />
                <Trees />
                
                <FlightController isPlaying={isPlaying} progress={progressRef} />
                
                <Environment preset="city" />
            </Canvas>

            {/* Overlay UI - HUD */}
            <div className="absolute top-0 left-0 w-full p-8 bg-gradient-to-b from-black/60 to-transparent pointer-events-none">
                <div className="flex justify-between items-start max-w-7xl mx-auto">
                    <div>
                        <h1 className="text-3xl md:text-5xl font-black text-white tracking-tight drop-shadow-md">
                            LOT MISTRZÓW
                        </h1>
                        <p className="text-blue-200 font-mono text-sm mt-1 flex items-center gap-2">
                            <MapIcon size={14} />
                            WIZUALIZACJA TERENOWA
                        </p>
                    </div>
                    <div className="text-right hidden md:block">
                        <div className="text-xs text-gray-400 uppercase tracking-widest">Lokalizacja</div>
                        <div className="text-white font-bold">REGION V • POLSKA</div>
                        <div className="text-xs text-gray-400 mt-1">51°06&apos;N 15°18&apos;E</div>
                    </div>
                </div>
            </div>

            {/* Controls */}
            <div className="absolute bottom-12 left-1/2 -translate-x-1/2 z-10 flex items-center gap-4 pointer-events-auto">
                <div className="bg-black/40 backdrop-blur-xl border border-white/10 p-2 rounded-full flex items-center gap-2 shadow-2xl">
                    <button
                        onClick={() => setIsPlaying(!isPlaying)}
                        className={`flex items-center gap-3 px-8 py-3 rounded-full font-bold transition-all duration-300 ${
                            isPlaying 
                            ? 'bg-white/10 text-white hover:bg-white/20' 
                            : 'bg-blue-600 text-white hover:bg-blue-500 shadow-lg shadow-blue-500/20'
                        }`}
                    >
                        {isPlaying ? <Pause size={20} fill="currentColor" /> : <Play size={20} fill="currentColor" />}
                        <span className="tracking-wide text-sm">{isPlaying ? 'WSTRZYMAJ LOT' : 'ROZPOCZNIJ LOT'}</span>
                    </button>
                    
                    <button
                        onClick={() => {
                            setIsPlaying(false);
                            progressRef.current = 0;
                        }}
                        className="p-3 text-white/70 hover:text-white hover:bg-white/10 rounded-full transition-colors"
                        title="Reset Camera"
                    >
                        <RotateCcw size={20} />
                    </button>
                </div>
            </div>

            {/* Vignette */}
            <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(circle_at_center,transparent_50%,rgba(0,0,0,0.4)_100%)]" />
        </div>
    );
}
