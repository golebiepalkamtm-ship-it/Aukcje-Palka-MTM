'use client';

import React, { useEffect, useRef, useState } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import type { YearAchievements } from '@/lib/achievements-parser';
import * as turf from '@turf/turf';
import { Play, Pause, RotateCcw } from 'lucide-react';
import { createRoot } from 'react-dom/client';

mapboxgl.accessToken = 'pk.eyJ1IjoibWFudGF4IiwiYSI6ImNtZmk5em1peDBnM3gyanFxcHpnZmtlZHgifQ.W2AbB_7HQqqBBJ72AGIxXg';

type NewJourneyMapProps = {
  data: YearAchievements[];
  onYearSelect?: (year: number | null) => void;
};

const ROUTE_COORDS: [number, number][] = [
  [19.455, 51.759], // Łódź
  [17.034, 51.110], // Wrocław
  [15.7, 50.8],     // Karkonosze
  [14.5, 50.5],     // Czechy
  [12.5, 50.2],     // Rudawy
  [11.5, 49.9],     // Frankonia
  [10.5, 48.5],     // Bawaria
  [11.0, 47.4],     // Alpy
];

const FLIGHT_SPEED_KMPH = 650;
const CAMERA_UPDATE_MS = 400;
const BANNER_OFFSET: [number, number] = [0, -140];

// Komponent Banera (Marker)
const ResultBanner = ({ yearData }: { yearData: YearAchievements }) => {
  const allAchievements = yearData.achievements;
  
  // Oblicz liczbę kolumn na podstawie liczby wyników
  const numResults = allAchievements.length;
  const columns = numResults <= 6 ? 1 : numResults <= 12 ? 2 : 3;
  
  return (
    <div 
      className="p-6 bg-black/90 backdrop-blur-md border border-yellow-500/50 rounded-lg shadow-2xl animate-in fade-in zoom-in duration-500"
      style={{
        display: 'grid',
        gridTemplateColumns: `repeat(${columns}, minmax(300px, 1fr))`,
        gap: '1rem',
        maxWidth: `${columns * 320}px`
      }}
    >
        <div 
          className="flex items-center justify-between mb-4 border-b border-white/10 pb-3 bg-black/90 z-10"
          style={{ gridColumn: `1 / ${columns + 1}` }}
        >
            <h3 className="text-4xl font-bold text-yellow-400 font-mono">{yearData.year}</h3>
            <span className="text-sm text-gray-400 uppercase tracking-widest">
              {allAchievements.length} {allAchievements.length === 1 ? 'Osiągnięcie' : 'Osiągnięć'}
            </span>
        </div>
        
        {allAchievements.map((ach, i) => (
            <div key={i} className="text-base border border-white/5 p-3 rounded-lg bg-black/40">
                <div className="text-sky-300 font-semibold whitespace-normal break-words mb-2">{ach.title}</div>
                <div className="flex justify-between text-sm text-gray-400 mt-1 flex-wrap gap-2">
                   <span className="whitespace-normal break-words">{ach.category}</span>
                   {ach.coeff !== '-' && <span className="font-mono text-yellow-600 whitespace-nowrap">{ach.coeff} coeff</span>}
                </div>
            </div>
        ))}
    </div>
  );
};

export default function NewJourneyMap({ data, onYearSelect }: NewJourneyMapProps) {
  const mapContainer = useRef<HTMLDivElement>(null);
  const mapRef = useRef<mapboxgl.Map | null>(null);
  
  // Startujemy od razu z pozycji pierwszego punktu trasy
  const START_CAMERA = {
    center: ROUTE_COORDS[0],
    zoom: 12.5,
    pitch: 70,
    bearing: turf.bearing(turf.point(ROUTE_COORDS[0]), turf.point(ROUTE_COORDS[1]))
  };

  const [isPlaying, setIsPlaying] = useState(false);
  const [currentYearIndex, setCurrentYearIndex] = useState(0);
  const shownYearsRef = useRef(new Set<number>()); // Proste śledzenie pokazanych lat
  const isPausedRef = useRef(false);
  const currentMarkerRef = useRef<mapboxgl.Marker | null>(null);

  useEffect(() => {
    if (!mapContainer.current || mapRef.current) return;
    
    // Ensure the container has dimensions before initializing
    if (mapContainer.current.clientWidth === 0 || mapContainer.current.clientHeight === 0) {
      console.warn('Map container has 0 dimensions, retrying in 100ms');
      setTimeout(() => {
        // Force a trigger for re-render if needed, but mainly just wait
      }, 100);
    }

    const map = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/satellite-streets-v12',
      center: START_CAMERA.center,
      zoom: START_CAMERA.zoom,
      pitch: START_CAMERA.pitch,
      bearing: START_CAMERA.bearing,
      antialias: true,
      attributionControl: false
    });

    mapRef.current = map;

        // Make map responsive immediately
    map.once('load', () => {
        map.resize();
        // Ukryj etykiety miast/miejscowości oraz drogi
        // W stylu satellite-streets-v12 warstwy etykiet mają zwykle w nazwie 'label'
        map.style.stylesheet.layers.forEach((layer: any) => {
            const isLabel = layer.type === 'symbol' && (layer.id.includes('settlement') || layer.id.includes('place') || layer.id.includes('label'));
            const isRoad = layer.id.includes('road') || layer.id.includes('bridge') || layer.id.includes('tunnel') || layer.id.includes('transit');
            
            if (isLabel || isRoad) {
                 map.setLayoutProperty(layer.id, 'visibility', 'none');
            }
        });
        
        console.log('Map loaded and ready');
    });

    map.on('load', () => {
      // ... setup layers ...
      map.addSource('mapbox-dem', {
        type: 'raster-dem',
        url: 'mapbox://mapbox.mapbox-terrain-dem-v1',
        tileSize: 512,
        maxzoom: 14
      });
      map.setTerrain({ source: 'mapbox-dem', exaggeration: 1.5 }); // Zredukowany efekt 3D dla płynności

      map.addLayer({
        id: 'sky',
        type: 'sky',
        paint: {
          'sky-type': 'atmosphere',
          'sky-atmosphere-sun': [0.0, 0.0],
          'sky-atmosphere-sun-intensity': 15
        }
      });

      const lineString = turf.lineString(ROUTE_COORDS);
      const bezier = turf.bezierSpline(lineString, { resolution: 20000, sharpness: 0.6 });
      const smoothCoords = bezier.geometry.coordinates;

      map.addSource('route', {
        type: 'geojson',
        data: {
          type: 'Feature',
          properties: {},
          geometry: {
            type: 'LineString',
            coordinates: smoothCoords
          }
        }
      });

      map.addLayer({
        id: 'route-line',
        type: 'line',
        source: 'route',
        layout: { 'line-join': 'round', 'line-cap': 'round' },
        paint: {
          'line-color': '#38bdf8',
          'line-width': 6,
          'line-opacity': 0.6,
          'line-blur': 1
        }
      });

      // Force resize with delay to ensure container is fully rendered
      setTimeout(() => {
        map.resize();
      }, 100);
      
      // Second resize check for safety
      setTimeout(() => {
        map.resize();
      }, 500);

      // Dodajemy punkty lat jako niewidoczne triggery (lub małe kropki)
      // Nie dodajemy tutaj banerów statycznie - będziemy je dodawać dynamicznie w trakcie jazdy
      addYearPoints(map, smoothCoords);
    });

    return () => {
      if (currentMarkerRef.current) {
          currentMarkerRef.current.remove();
      }
      map.remove();
      mapRef.current = null;
    };
  }, [data, onYearSelect]);

  // Handle window resize
  useEffect(() => {
    const handleResize = () => {
      if (mapRef.current) {
        mapRef.current.resize();
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const addYearPoints = (map: mapboxgl.Map, pathCoords: any[]) => {
    const features = data.map((yearData, index) => {
      const coordIndex = Math.floor((index / Math.max(data.length - 1, 1)) * (pathCoords.length - 1));
      const coord = pathCoords[coordIndex];
      
      return {
        type: 'Feature',
        properties: {
          year: yearData.year,
          index: index,
          title: `Rok ${yearData.year}`,
        },
        geometry: {
          type: 'Point',
          coordinates: coord
        }
      };
    });

    map.addSource('years-points', {
      type: 'geojson',
      data: { type: 'FeatureCollection', features: features as any }
    });

    map.addLayer({
      id: 'years-circles',
      type: 'circle',
      source: 'years-points',
      paint: {
        'circle-radius': 8,
        'circle-color': '#facc15',
        'circle-stroke-width': 2,
        'circle-stroke-color': '#ffffff'
      }
    });
    
    // Etykieta roku na mapie (zawsze widoczna)
    map.addLayer({
        id: 'years-labels',
        type: 'symbol',
        source: 'years-points',
        layout: {
          'text-field': '{year}',
          'text-font': ['DIN Offc Pro Medium', 'Arial Unicode MS Bold'],
          'text-size': 14,
          'text-offset': [0, 1.5], // Pod punktem
          'text-anchor': 'top',
          'text-allow-overlap': true
        },
        paint: {
          'text-color': '#ffffff',
          'text-halo-color': '#000000',
          'text-halo-width': 2
        }
    });

    const handleFeatureSelect = (features?: mapboxgl.MapboxGeoJSONFeature[]) => {
      if (!features?.length) return;
      const feature = features[0];
      const index = Number(feature.properties?.index ?? -1);
      const yearData = index >= 0 ? data[index] : null;
      if (!yearData) return;
      const coords =
        feature.geometry.type === 'Point'
          ? (feature.geometry.coordinates as [number, number])
          : ((feature.geometry as any)?.coordinates as [number, number]);
      shownYearsRef.current.add(yearData.year);
      setCurrentYearIndex(index);
      showResultBanner(map, coords, yearData);
    };

    const handleClick = (e: mapboxgl.MapLayerMouseEvent) => {
      handleFeatureSelect(e.features);
    };

    const handleMouseEnter = () => {
      map.getCanvas().style.cursor = 'pointer';
    };

    const handleMouseLeave = () => {
      map.getCanvas().style.cursor = '';
    };

    map.on('click', 'years-circles', handleClick);
    map.on('click', 'years-labels', handleClick);
    map.on('mouseenter', 'years-circles', handleMouseEnter);
    map.on('mouseleave', 'years-circles', handleMouseLeave);
  };

  // Funkcja dodająca Marker HTML z React Component
  const showResultBanner = (map: mapboxgl.Map, coord: [number, number], yearData: YearAchievements) => {
      // KRYTYCZNE: Usuń poprzedni marker ZANIM dodasz nowy
      // To gwarantuje, że nigdy nie będzie "stosu" banerów
      if (currentMarkerRef.current) {
          currentMarkerRef.current.remove();
          currentMarkerRef.current = null;
      }

      const el = document.createElement('div');
      const root = createRoot(el);
      root.render(<ResultBanner yearData={yearData} />);

      // Stwórz marker
      const marker = new mapboxgl.Marker({
          element: el,
          anchor: 'bottom',
          offset: BANNER_OFFSET
      })
      .setLngLat(coord)
      .addTo(map);

      currentMarkerRef.current = marker;
      onYearSelect?.(yearData.year);
      
      // Auto-cleanup po 10 sekundach
      setTimeout(() => {
          if (currentMarkerRef.current === marker) {
              marker.remove();
              currentMarkerRef.current = null;
              setTimeout(() => root.unmount(), 0);
          }
      }, 10000);
      
      return marker;
  };
  
  const clearMarkers = () => {
      if (currentMarkerRef.current) {
          currentMarkerRef.current.remove();
          currentMarkerRef.current = null;
      }
  };

  const playAnimation = async () => {
    if (!mapRef.current) return;
    const map = mapRef.current;
    setIsPlaying(true);
    isPausedRef.current = false;
    
    // Wyczyść markery i historię przy starcie od nowa
    if (currentYearIndex === 0) {
        clearMarkers();
        shownYearsRef.current.clear();
    }

    const lineString = turf.lineString(ROUTE_COORDS);
    const bezier = turf.bezierSpline(lineString, { resolution: 20000, sharpness: 0.6 });
    const pathCoords = bezier.geometry.coordinates;

    const yearPathIndices = data.map((_, i) => 
        Math.floor((i / Math.max(data.length - 1, 1)) * (pathCoords.length - 1))
    );

    let currentPathIndex = 0;
    const endPathIndex = pathCoords.length - 1;

    // Oblicz długość trasy dla interpolacji czasowej
    const line = turf.lineString(pathCoords);
    const totalDistance = turf.length(line); // km
    
    // Parametry lotu
    const speedPerMs = FLIGHT_SPEED_KMPH / 3600 / 1000; // km/ms

    let traveledDistance = 0;
    let lastTimestamp: number | null = null;

    const animateFrame = (timestamp: number) => {
        if (isPausedRef.current) {
            setIsPlaying(false);
            return;
        }

        if (lastTimestamp === null) {
            lastTimestamp = timestamp;
        }

        const delta = timestamp - lastTimestamp;
        lastTimestamp = timestamp;

        traveledDistance += delta * speedPerMs;
        
        if (traveledDistance >= totalDistance) {
            setIsPlaying(false);
            return;
        }

        // Znajdź pozycję na trasie
        const currentPoint = turf.along(line, traveledDistance);
        const coord = currentPoint.geometry.coordinates as [number, number];
        
        const progress = traveledDistance / totalDistance;
        const newPathIndex = Math.floor(progress * endPathIndex);
        
        // PROSTA LOGIKA: Sprawdź każdy rok po kolei
        for (let i = 0; i < data.length; i++) {
            const yearPathIdx = yearPathIndices[i];
            const yearNum = data[i].year;
            
            // Jeśli ten rok nie był pokazany I jesteśmy już przy jego pozycji
            if (!shownYearsRef.current.has(yearNum) && newPathIndex >= yearPathIdx) {
                shownYearsRef.current.add(yearNum);
                showResultBanner(map, coord, data[i]);
                setCurrentYearIndex(i);
                break; // Pokaż tylko jeden na raz
            }
        }

        // Oblicz bearing dla kamery - look ahead więcej dla płynniejszego efektu
        const lookAheadDistance = Math.min(traveledDistance + 40, totalDistance);
        const lookAheadPoint = turf.along(line, lookAheadDistance);
        const bearing = turf.bearing(currentPoint, lookAheadPoint);
        
        if (newPathIndex !== currentPathIndex) {
          currentPathIndex = newPathIndex;
          map.stop();
          map.easeTo({
            center: coord as mapboxgl.LngLatLike,
            bearing,
            pitch: START_CAMERA.pitch,
            zoom: START_CAMERA.zoom - 0.5,
            duration: CAMERA_UPDATE_MS,
            easing: t => t,
          });
        }
        
        requestAnimationFrame(animateFrame);
    };

    requestAnimationFrame(animateFrame);
  };

  const handlePause = () => {
      isPausedRef.current = true;
      setIsPlaying(false);
  };

  const handleReset = () => {
      isPausedRef.current = true;
      setIsPlaying(false);
      setCurrentYearIndex(0);
      shownYearsRef.current.clear(); // Wyczyść historię pokazanych lat
      clearMarkers();
      onYearSelect?.(null);
      
      mapRef.current?.flyTo({
          ...START_CAMERA,
          speed: 1.5
      });
  };

  return (
    <div className="relative w-full h-full" style={{ width: '100vw', height: '100vh' }}>
      <div ref={mapContainer} className="absolute inset-0 w-full h-full" style={{ width: '100%', height: '100%' }} />
      
      <div className="absolute bottom-24 left-1/2 -translate-x-1/2 z-50 flex items-center gap-4 bg-black/60 backdrop-blur-md p-3 rounded-full border border-white/10">
          {!isPlaying ? (
             <button 
                onClick={playAnimation}
                className="flex items-center gap-2 bg-white text-black px-6 py-2 rounded-full font-bold hover:bg-gray-200 transition-colors"
             >
               <Play size={18} fill="currentColor" />
               {currentYearIndex > 0 ? 'Wznów trasę' : 'Start trasy'}
             </button>
          ) : (
             <button 
                onClick={handlePause}
                className="flex items-center gap-2 bg-white/10 text-white px-6 py-2 rounded-full font-medium hover:bg-white/20 transition-colors"
             >
               <Pause size={18} fill="currentColor" />
               Pauza
             </button>
          )}
          
          <button 
             onClick={handleReset}
             className="p-2 text-gray-400 hover:text-white transition-colors"
             title="Resetuj trasę"
          >
            <RotateCcw size={20} />
          </button>
      </div>
    </div>
  );
}
